package org.libertas.bd;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.LinkedList;

public class CidadesDao {
    public void inserir(Cidades c) {
        ConexaoBD con = new ConexaoBD();
        try {
                String sql = "INSERT INTO cidades (nome, uf, populacao, pais)"
                        + "VALUES (?,?,?,?)";
                PreparedStatement prep = con.getConnection().prepareStatement(sql);               
                prep.setString(1, c.getNome());
                prep.setString(2, c.getUf());
                prep.setString(3, c.getPopulacao());
                prep.setString(4, c.getPais());
                prep.execute();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            con.desconectar();
        }
    }
	
	public void alterar(Cidades c){
		ConexaoBD con = new ConexaoBD();
		try {
			
			String sql = "UPDATE cidades SET nome=?, uf=?, populacao=?, pais=? WHERE idcidade=?";
			PreparedStatement prep = con.getConnection().prepareStatement(sql);
			prep.setString(1, c.getNome());
			prep.setString(2, c.getUf());
			prep.setString(3, c.getPopulacao());
			prep.setString(4, c.getPais());
			prep.setInt(5, c.getIdcidade());
			prep.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.desconectar();
		}
		
	}
	
	public void excluir(Cidades c){
		ConexaoBD con = new ConexaoBD();
	try {
			
			String sql = "DELETE FROM cidades WHERE idcidade=?";
			PreparedStatement prep = con.getConnection().prepareStatement(sql);
			prep.setInt(1, c.getIdcidade());
			prep.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.desconectar();
		}
	}
	
	
	public boolean existeCidade(int id) {
		ConexaoBD con = new ConexaoBD();
		boolean existe = false;
		try {
			String sql = "SELECT 1 FROM cidades WHERE idcidade=?";
	        PreparedStatement prep = con.getConnection().prepareStatement(sql);
	        prep.setInt(1, id);
	        ResultSet res = prep.executeQuery();
	        
	        if (res.next()) {
	            existe = true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        con.desconectar();
	    }
	    return existe;
	}
		
	
	public Cidades consultar(int id) {
	    ConexaoBD con = new ConexaoBD();
	    Cidades c = new Cidades();
	    try {
	        String sql = "SELECT * FROM cidades WHERE idcidade=?";
	        PreparedStatement prep = con.getConnection().prepareStatement(sql);
	        prep.setInt(1, id);
	        ResultSet res = prep.executeQuery();
	        if (res.next()) {
	            c.setIdcidade(res.getInt("idcidade"));
	            c.setNome(res.getString("nome"));
	            c.setUf(res.getString("uf"));
	            c.setPopulacao(res.getString("populacao"));
	            c.setPais(res.getString("pais"));
	        }
	        prep.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        con.desconectar();
	    }
	    return c;
	}
	
	public List<Cidades> listar(){
		List<Cidades> lista = new LinkedList<Cidades>();
		ConexaoBD con = new ConexaoBD();
		try {
			
			String sql = "SELECT * FROM cidades ORDER BY idcidade";
			PreparedStatement prep = con.getConnection().prepareStatement(sql);
			ResultSet res = prep.executeQuery();
			while (res.next()) {
				Cidades c = new Cidades();
				c.setIdcidade(res.getInt("idcidade"));
	            c.setNome(res.getString("nome"));
	            c.setUf(res.getString("uf"));
	            c.setPopulacao(res.getString("populacao"));
	            c.setPais(res.getString("pais"));
				lista.add(c);
			}
			prep.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.desconectar();
		}
		return lista;
	}
}
