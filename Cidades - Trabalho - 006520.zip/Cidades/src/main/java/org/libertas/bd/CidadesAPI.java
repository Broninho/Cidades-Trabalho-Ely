package org.libertas.bd;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.libertas.c.Retorno;

import com.google.gson.*;


/**
 * Servlet implementation class CidadesAPI
 */
public class CidadesAPI extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CidadesAPI() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		
		CidadesDao adao = new CidadesDao();
		List<Cidades> dados = adao.listar();
		Gson gson = new Gson();
		out.print(gson.toJson(dados));
}

	/**
	 * @see HttpServlet#doPost(HttpServletReques	t request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		
		try{
			StringBuilder sb = new StringBuilder();
			BufferedReader reader = request.getReader();
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
			String body = sb.toString();
			
			Gson gson = new Gson();
			Cidades c = gson.fromJson(body,Cidades.class);
					
			CidadesDao cdao = new CidadesDao();
			cdao.inserir(c);
			
			Retorno r = new Retorno(true, "Registro inserido com sucesso!");
			out.print(gson.toJson(r));
		} catch (Exception e) {
			Gson gson = new Gson();
			e.printStackTrace();
			Retorno r = new Retorno(false, e.getMessage());
			out.print(gson.toJson(r));
		}
		
	}
	
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		
		try {
			StringBuilder sb = new StringBuilder();
			BufferedReader reader = request.getReader();
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
			String body = sb.toString();
			
			
			Gson gson = new Gson();
			Cidades c = gson.fromJson(body,Cidades.class);
					
			CidadesDao cdao = new CidadesDao();
			cdao.alterar(c);
			
			Retorno r = new Retorno(true, "Registro alterado com sucesso!");
			out.print(gson.toJson(r));
		} catch (Exception e) {
			Gson gson = new Gson();
			e.printStackTrace();
			Retorno r = new Retorno(false, e.getMessage());
			out.print(gson.toJson(r));
		}
	}
	
	   protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		try {
			String id = request.getRequestURI();
			id = id.substring(id.lastIndexOf("/")+1);
			
		
			CidadesDao cdao = new CidadesDao();
			Cidades c = new Cidades();
			c.setIdcidade(Integer.parseInt(id));
			cdao.excluir(c);
					
			Retorno r = new Retorno(true, "Registro excluido com sucesso!");
			Gson gson = new Gson();
			out.print(gson.toJson(r));
		} catch (Exception e) {
			e.printStackTrace();
			Gson gson = new Gson();
			Retorno r = new Retorno(false, e.getMessage());
			out.print(gson.toJson(r));
		}
	}
	
	

}
