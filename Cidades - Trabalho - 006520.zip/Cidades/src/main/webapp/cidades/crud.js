var val = [];
var idcidade = 0;
function novo(){
	var form = document.getElementById("formulario");
	var lista = document.getElementById("lista");
	var b = document.getElementById("b");
	form.style.display = "block";
	
	lista.style.display = "none";
	
	b.style.display = "none";
	
	idcidade = 0;
	var nome = document.getElementById("nome");
	var uf = document.getElementById("uf");
	var populacao = document.getElementById("populacao");
	var pais = document.getElementById("pais");
	nome.value = "";
	uf.value = "";
	populacao.value = "";
	pais.value = "";
	
	nome.focus();
		
}

function salvar(){
	if (document.getElementById("nome").value == ""){
		alert("Campo Nome é obrigatório!")
		return;
	} else if (document.getElementById("uf").value == ""){
		alert("Campo Uf é obrigatório!")
		return;
	}else if (document.getElementById("populacao").value == ""){
		alert("Campo populacao é obrigatório!")
		return;
	}else if (document.getElementById("pais").value == ""){
		alert("Campo p é obrigatório!")
		return;
	}
	
	var p = {
	idcidade: idcidade,
	nome: document.getElementById("nome").value,
	uf: document.getElementById("uf").value,
	populacao: document.getElementById("populacao").value,
	pais: document.getElementById("pais").value
};
	
	if(idcidade == 0){
		metodo = "POST";
	}else{
		metodo = "PUT";
	}
	
	
	fetch("http://localhost:8080/Cidades/CidadesAPI",
		{method: metodo,
		 body: JSON.stringify(p)
		 }
	)
	.then(resp => resp.json())
	.then(function(retorno){
		alert(retorno.mensagem);
		
		var form = document.getElementById("formulario");
		var lista = document.getElementById("lista");
		
		form.style.display = "none";
		
		lista.style.display = "block";

		listar();
	});
}

function cancelar(){
	var form = document.getElementById("formulario");
	var lista = document.getElementById("lista");
	var b = document.getElementById("b");
	
	form.style.display = "none";
	
	lista.style.display = "block";
	
	b.style.display = "block";
}


function listar(){
	var lista = document.getElementById("dados");
	lista.innerHTML = "<tr><td colspan=4>Aguarde, carregando...</td></tr>";
	
	fetch("http://localhost:8080/Cidades/CidadesAPI")
	.then(resp => resp.json())
	.then(dados => mostrar(dados));
}
	
function mostrar(dados){
	valores = dados;
	var lista = document.getElementById("dados");
	lista.innerHTML = "";
	for (var i in dados){
		lista.innerHTML += "<tr>" +
    "<td>" + dados[i].idcidade + "</td>" +
    "<td>" + dados[i].nome + "</td>" +
    "<td>" + dados[i].uf + "</td>" +
    "<td>" + dados[i].populacao + "</td>" +
    "<td>" + dados[i].pais + "</td>" +
    '<td><input type="button" value="Excluir" onclick="excluir(' + i + ')"/></td>' +
    '<td><input type="button" value="Alterar" onclick="alterar(' + i + ')"/></td>' +
    "</tr>";
    }

	
}

function excluir(i) {
	
	idcidade = valores[i].idcidade;

	fetch("http://localhost:8080/Cidades/CidadesAPI/" + idcidade,
		{method: "DELETE"
		}
	)
	.then(resp => resp.json())
	.then(function(retorno){
		alert(retorno.mensagem);
		
		var form = document.getElementById("formulario");
		var lista = document.getElementById("lista");
		
		form.style.display = "none";
		
		lista.style.display = "block";

		listar();
	});
}

function alterar(i) {
	var form = document.getElementById("formulario");
	var lista = document.getElementById("lista");
	var b = document.getElementById("b");
	
	
	b.style.display = "none";
	
	form.style.display = "block";
	
	lista.style.display = "none";
	

	idcidade = valores[i].idcidade;
	var nome = document.getElementById("nome");
	var uf = document.getElementById("uf");
	var populacao = document.getElementById("populacao");
	var pais = document.getElementById("pais");
	nome.value = valores[i].nome;
	uf.value = valores[i].uf;
	populacao.value = valores[i].populacao;
	pais.value = valores[i].pais;
	
	nome.focus();
 
}

listar();

